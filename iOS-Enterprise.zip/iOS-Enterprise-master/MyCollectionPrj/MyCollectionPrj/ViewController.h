//
//  ViewController.h
//  MyCollectionPrj
//
//  Created by lingzhi on 16/6/30.
//  Copyright © 2016年 NCUT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

