//
//  AppDelegate.h
//  MyCollectionPrj
//
//  Created by lingzhi on 16/6/30.
//  Copyright © 2016年 NCUT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

