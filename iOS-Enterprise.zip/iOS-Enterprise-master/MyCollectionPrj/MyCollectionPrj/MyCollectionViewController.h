//
//  MyCollectionViewController.h
//  MyCollectionPrj
//
//  Created by lingzhi on 16/7/1.
//  Copyright © 2016年 NCUT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyCollectionViewController : UICollectionViewController

@end
