//
//  main.m
//  Notification_transfer
//
//  Created by apple on 16/6/20.
//  Copyright © 2016年 EL-Apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
