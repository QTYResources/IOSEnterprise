//
//  SceneAViewController.h



#import <UIKit/UIKit.h>

@interface SceneAViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *showInformation;
@property (weak, nonatomic) IBOutlet UIButton *buttonA;

@end



