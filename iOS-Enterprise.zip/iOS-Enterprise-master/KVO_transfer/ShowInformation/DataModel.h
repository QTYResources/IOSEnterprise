//
//  DataModel.h
//  ShowInformation
//
//  Created by lingzhi on 16/6/20.
//  Copyright © 2016年 lingzhi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DataModel : NSObject

@property (nonatomic , strong) NSString* stringPassed;

@end
