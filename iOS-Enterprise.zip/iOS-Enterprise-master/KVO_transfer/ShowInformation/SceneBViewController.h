//
//  SceneBViewController.h


#import <UIKit/UIKit.h>


@interface SceneBViewController : UIViewController <UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITextField *inputInformation;



@end
