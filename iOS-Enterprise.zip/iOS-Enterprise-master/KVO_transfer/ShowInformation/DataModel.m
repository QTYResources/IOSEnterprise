//
//  DataModel.m
//  ShowInformation
//
//  Created by lingzhi on 16/6/20.
//  Copyright © 2016年 lingzhi. All rights reserved.
//

#import "DataModel.h"

@implementation DataModel

@end
