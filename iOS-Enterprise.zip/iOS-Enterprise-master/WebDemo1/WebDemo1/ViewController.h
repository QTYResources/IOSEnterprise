//
//  ViewController.h
//  WebDemo1
//
//  Created by lingzhi on 17/6/29.
//  Copyright © 2017年 ncut. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

