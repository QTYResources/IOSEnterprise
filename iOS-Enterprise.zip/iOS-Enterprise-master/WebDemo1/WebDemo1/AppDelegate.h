//
//  AppDelegate.h
//  WebDemo1
//
//  Created by lingzhi on 17/6/29.
//  Copyright © 2017年 ncut. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

