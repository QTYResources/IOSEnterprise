//
//  main.m
//  WebDemo1
//
//  Created by lingzhi on 17/6/29.
//  Copyright © 2017年 ncut. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
